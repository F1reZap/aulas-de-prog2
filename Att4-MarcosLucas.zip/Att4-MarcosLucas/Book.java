public class Book
{
    // Campos.
    private String author;
    private String title;
    private int pages;
    private String refNumber;
    private int borrowed;

    /**
     * Constrói um Book com autor, título e número de páginas.
     * O refNumber é inicializado com string vazia.
     */
    public Book(String bookAuthor, String bookTitle, int bookPages)
    {
        author = bookAuthor;
        title = bookTitle;
        pages = bookPages;
        refNumber = "";
        borrowed = 0;
    }

    // Métodos de acesso simples
    public String getAuthor()
    {
        return author;
    }

    public String getTitle()
    {
        return title;
    }

    public int getPages()
    {
        return pages;
    }

    public String getRefNumber()
    {
        return refNumber;
    }

    public int getBorrowed()
    {
        return borrowed;
    }

    // Métodos de impressão simples
    public void printAuthor()
    {
        System.out.println(author);
    }

    public void printTitle()
    {
        System.out.println(title);
    }

    /**
     * Imprime detalhes: title, author, pages, refNumber (ou "ZZZ" se não configurado)
     * e o número de vezes emprestado.
     */
    public void printDetails()
    {
        String refToPrint = (refNumber.length() == 0) ? "ZZZ" : refNumber;
        System.out.println("Title: " + title + ", Author: " + author + ", Pages: " + pages);
        System.out.println("RefNumber: " + refToPrint + ", Borrowed: " + borrowed);
    }

    /**
     * Define o refNumber somente se a string tiver pelo menos 3 caracteres.
     * Caso contrário imprime mensagem de erro e não altera o campo.
     */
    public void setRefNumber(String ref)
    {
        if (ref == null) {
            System.out.println("Erro: refNumber não pode ser null.");
            return;
        }
        if (ref.length() >= 3) {
            refNumber = ref;
        } else {
            System.out.println("Erro: refNumber deve ter ao menos 3 caracteres. Não alterado.");
        }
    }

    /**
     * Incrementa a contagem de vezes que o livro foi emprestado.
     */
    public void borrow()
    {
        borrowed++;
    }
}