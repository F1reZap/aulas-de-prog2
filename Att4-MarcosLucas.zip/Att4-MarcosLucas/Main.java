public class Main
{
    public static void main(String[] args)
    {
        System.out.println("== Teste Book ==");
        Book b1 = new Book("Daniel Defoe", "Robinson Crusoe", 232);
        Book b2 = new Book("George Orwell", "1984", 328);

        System.out.println("getAuthor/getTitle:");
        System.out.println(b1.getAuthor() + " - " + b1.getTitle());
        System.out.println(b2.getAuthor() + " - " + b2.getTitle());

        System.out.print("printAuthor/printTitle: ");
        b1.printAuthor();
        b1.printTitle();

        System.out.println("Detalhes (antes refNumber):");
        b1.printDetails(); // deve mostrar ZZZ

        System.out.println("Tentando setRefNumber curto:");
        b1.setRefNumber("AB"); // inválido
        System.out.println("Tentando setRefNumber válido:");
        b1.setRefNumber("A12"); // válido
        b1.printDetails();

        System.out.println("Emprestando livro...");
        b1.borrow();
        b1.borrow();
        System.out.println("Borrowed count: " + b1.getBorrowed());

        System.out.println("\n== Teste Heater ==");
        Heater h = new Heater(10, 20); // min=10, max=20, temp inicial 15
        System.out.println("Temp inicial: " + h.getTemperature());
        h.warmer();
        System.out.println("Depois warmer: " + h.getTemperature());
        h.setIncrement(3);
        h.warmer();
        System.out.println("Depois warmer com inc=3: " + h.getTemperature());
        h.setIncrement(-5); // deve imprimir erro e não alterar
        System.out.println("Increment atual: " + h.getIncrement());
        // testar limites
        h.setIncrement(10);
        h.warmer(); // chegará ao max (20)
        System.out.println("Depois warmer até max: " + h.getTemperature());
        h.cooler();
        System.out.println("Depois cooler: " + h.getTemperature());

        System.out.println("\n== Teste TicketMachine ==");
        TicketMachine tm = new TicketMachine(50); // preço 50 cents
        tm.insertMoney(30);
        tm.printTicket(); // saldo insuficiente, mostra faltam 20
        tm.insertMoney(30);
        tm.printTicket(); // imprime e devolve troco 10
        // inserir mais e imprimir
        tm.insertMoney(50);
        tm.printTicket();
        System.out.println("Esvaziando máquina (total acumulado): " + tm.emptyMachine());
        System.out.println("Esvaziando de novo (deve ser 0): " + tm.emptyMachine());
    }
}