public class TicketMachine
{
    private int price;
    private int balance;
    private int total;

    public TicketMachine(int ticketCost)
    {
        if (ticketCost <= 0) {
            throw new IllegalArgumentException("O preço do bilhete deve ser maior que zero.");
        }
        price = ticketCost;
        balance = 0;
        total = 0;
    }

    public int getPrice()
    {
        return price;
    }

    public int getBalance()
    {
        return balance;
    }

    public void insertMoney(int amount)
    {
        if (amount <= 0) {
            throw new IllegalArgumentException("Valor inserido deve ser positivo.");
        }
        balance += amount;
    }

    /**
     * Tenta imprimir um bilhete. Usando amountLeftToPay conforme exercício:
     * Se amountLeftToPay <= 0 imprime e devolve troco; caso contrário informa quanto falta.
     */
    public int printTicket()
    {
        int amountLeftToPay = price - balance;
        if (amountLeftToPay > 0) {
            System.out.println("Saldo insuficiente. Faltam " + amountLeftToPay + " cents.");
            return 0;
        }

        // Simula impressão do bilhete
        System.out.println("##################");
        System.out.println("# The BlueJ Line");
        System.out.println("# Ticket");
        System.out.println("# " + price + " cents.");
        System.out.println("##################");
        System.out.println();

        total += price;
        balance -= price;
        int troco = balance;
        balance = 0; // Troco devolvido, saldo zerado
        if (troco > 0) {
            System.out.println("Troco devolvido: " + troco + " cents.");
        }
        return troco;
    }

    /**
     * Esvazia a máquina: retorna o total acumulado e zera o total.
     */
    public int emptyMachine()
    {
        int amount = total;
        total = 0;
        return amount;
    }
}