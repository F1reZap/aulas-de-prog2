public class Heater
{
    private int temperature;
    private int min;
    private int max;
    private int increment;

    /**
     * Construtor sem parâmetros: define min=0, max=100, increment=5, temperature=15.
     */
    public Heater()
    {
        this(0, 100, 5, 15);
    }

    /**
     * Construtor com min e max; increment fixo em 5; temperatura inicial 15,
     * mas garantida dentro dos limites min/max.
     */
    public Heater(int min, int max)
    {
        this(min, max, 5, 15);
    }

    /**
     * Construtor completo (utilitário interno) para inicializar todos os campos.
     */
    public Heater(int min, int max, int increment, int initialTemperature)
    {
        if (min > max) {
            // Inverte se parâmetros estiverem errados
            int tmp = min;
            min = max;
            max = tmp;
        }
        this.min = min;
        this.max = max;
        this.increment = (increment >= 0) ? increment : 5;
        // Ajusta temperatura inicial para ficar dentro dos limites
        if (initialTemperature < min) {
            this.temperature = min;
        } else if (initialTemperature > max) {
            this.temperature = max;
        } else {
            this.temperature = initialTemperature;
        }
    }

    public int getTemperature()
    {
        return temperature;
    }

    /**
     * Aumenta a temperatura em increment, sem ultrapassar max.
     */
    public void warmer()
    {
        int newTemp = temperature + increment;
        if (newTemp > max) {
            temperature = max;
        } else {
            temperature = newTemp;
        }
    }

    /**
     * Diminui a temperatura em increment, sem ficar abaixo de min.
     */
    public void cooler()
    {
        int newTemp = temperature - increment;
        if (newTemp < min) {
            temperature = min;
        } else {
            temperature = newTemp;
        }
    }

    /**
     * Define o incremento; não permite valores negativos.
     */
    public void setIncrement(int inc)
    {
        if (inc < 0) {
            System.out.println("Erro: increment não pode ser negativo. Valor não alterado.");
            return;
        }
        this.increment = inc;
    }

    public int getMin()
    {
        return min;
    }

    public int getMax()
    {
        return max;
    }

    public int getIncrement()
    {
        return increment;
    }
}