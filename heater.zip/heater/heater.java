
/**
 * Escreva uma descrição da classe heater aqui.
 * 
 * @author (Marcos Lucas) 
 * @version (20/10/25)
 */
public class heater
{public class Heater
{
    private int temperature;
    private int min;
    private int max;
    private int increment;

    public Heater()
    {
        this(0, 100, 5, 15);
    }

    public Heater(int min, int max)
    {
        this(min, max, 5, 15);
    }

    public Heater(int min, int max, int increment, int initialTemperature)
    {
        if (min > max) {
            int tmp = min;
            min = max;
            max = tmp;
        }
        this.min = min;
        this.max = max;
        this.increment = (increment >= 0) ? increment : 5;
        if (initialTemperature < min) {
            this.temperature = min;
        } else if (initialTemperature > max) {
            this.temperature = max;
        } else {
            this.temperature = initialTemperature;
        }
    }

    public int getTemperature()
    {
        return temperature;
    }

    public void warmer()
    {
        int newTemp = temperature + increment;
        if (newTemp > max) {
            temperature = max;
        } else {
            temperature = newTemp;
        }
    }

    public void cooler()
    {
        int newTemp = temperature - increment;
        if (newTemp < min) {
            temperature = min;
        } else {
            temperature = newTemp;
        }
    }

    public void setIncrement(int inc)
    {
        if (inc < 0) {
            System.out.println("Erro: increment não pode ser negativo. Valor não alterado.");
            return;
        }
        this.increment = inc;
    }

    public int getMin()
    {
        return min;
    }

    public int getMax()
    {
        return max;
    }

    public int getIncrement()
    {
        return increment;
    }
}
}